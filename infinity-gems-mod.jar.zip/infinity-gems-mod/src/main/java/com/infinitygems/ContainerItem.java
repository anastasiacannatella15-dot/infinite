package com.infinitygems;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Un contenitore (cubo, scettro, sfera...) con dentro una gemma.
 * Clic destro: usa la gemma. Maiusc + clic destro: estrae la gemma e ti lascia una Custodia Vuota.
 */
public class ContainerItem extends Item {
	private final GemType type;

	public ContainerItem(GemType type, Settings settings) {
		super(settings);
		this.type = type;
	}

	public GemType getType() {
		return type;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (user.isSneaking()) {
			if (!world.isClient()) {
				if (!user.getAbilities().creativeMode) {
					stack.decrement(1);
				}
				user.getInventory().offerOrDrop(new ItemStack(ModItems.GEMS.get(type)));
				user.getInventory().offerOrDrop(new ItemStack(ModItems.EMPTY_CASE));
			}
			return TypedActionResult.success(stack, world.isClient());
		}

		if (type.tryUse(world, user)) {
			return TypedActionResult.success(stack, world.isClient());
		}
		return TypedActionResult.fail(stack);
	}

	@Override
	public boolean hasGlint(ItemStack stack) {
		return true;
	}

	@Override
	public void appendTooltip(ItemStack stack, @Nullable World world, List<Text> tooltip, TooltipContext context) {
		tooltip.add(Text.translatable("item.infinity_gems." + type.getStoneId() + ".tooltip").formatted(Formatting.GRAY));
		tooltip.add(Text.translatable("item.infinity_gems.container.tooltip").formatted(Formatting.DARK_GRAY));
	}
}
