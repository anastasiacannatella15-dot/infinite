package com.infinitygems;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** La schermata del guanto: clicca una gemma per sceglierla. */
@Environment(EnvType.CLIENT)
public class GauntletScreen extends Screen {
	private static final Identifier TEXTURE = new Identifier(InfinityGemsMod.MOD_ID, "textures/gui/gauntlet.png");
	private static final int TEX = 128;
	private static final int SLOT = 20;
	/** Angolo in alto a sinistra di ogni incastro, nell'ordine di GemType. */
	private static final int[][] SLOTS = {{18, 40}, {40, 40}, {62, 40}, {84, 40}, {51, 66}, {104, 52}};

	public GauntletScreen() {
		super(Text.translatable("item.infinity_gems.gauntlet"));
	}

	private ItemStack gauntlet() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) {
			return ItemStack.EMPTY;
		}
		ItemStack main = mc.player.getMainHandStack();
		if (main.getItem() instanceof GauntletItem) {
			return main;
		}
		ItemStack off = mc.player.getOffHandStack();
		return off.getItem() instanceof GauntletItem ? off : ItemStack.EMPTY;
	}

	private float scale() {
		return Math.max(0.5F, Math.min(2.0F, (height - 70) / (float) TEX));
	}

	private int left(float s) {
		return (int) ((width - TEX * s) / 2.0F);
	}

	private int top(float s) {
		return 22;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		renderBackground(ctx);
		ItemStack stack = gauntlet();
		float s = scale();
		int left = left(s);
		int top = top(s);

		ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 6, 0xFFFFFF);

		int selected = stack.isEmpty() ? -1 : GauntletItem.selectedMode(stack);

		MatrixStack m = ctx.getMatrices();
		m.push();
		m.translate(left, top, 0.0F);
		m.scale(s, s, 1.0F);
		ctx.drawTexture(TEXTURE, 0, 0, 0, 0, TEX, TEX, TEX, TEX);
		for (GemType type : GemType.values()) {
			int sx = SLOTS[type.ordinal()][0];
			int sy = SLOTS[type.ordinal()][1];
			if (!stack.isEmpty() && GauntletItem.hasStone(stack, type)) {
				ctx.drawItem(new ItemStack(ModItems.GEMS.get(type)), sx + 2, sy + 2);
				if (selected == type.ordinal()) {
					ctx.fill(sx - 1, sy - 1, sx + SLOT + 1, sy, 0xFFFFFFFF);
					ctx.fill(sx - 1, sy + SLOT, sx + SLOT + 1, sy + SLOT + 1, 0xFFFFFFFF);
					ctx.fill(sx - 1, sy, sx, sy + SLOT, 0xFFFFFFFF);
					ctx.fill(sx + SLOT, sy, sx + SLOT + 1, sy + SLOT, 0xFFFFFFFF);
				}
			}
		}
		m.pop();

		// Pulsante dello Schiocco (compare con tutte e 6 le gemme).
		boolean snap = !stack.isEmpty() && GauntletItem.modes(stack).contains(GauntletItem.SNAP);
		int by = top + (int) (TEX * s) + 6;
		if (snap) {
			int bx = width / 2 - 45;
			boolean on = selected == GauntletItem.SNAP;
			ctx.fill(bx, by, bx + 90, by + 18, on ? 0xFFFFFFFF : 0xFF000000);
			ctx.fill(bx + 1, by + 1, bx + 89, by + 17, on ? 0xFF8A6A10 : 0xFF2A2118);
			ctx.drawCenteredTextWithShadow(textRenderer, GauntletItem.modeName(GauntletItem.SNAP), width / 2, by + 5, 0xFFFFFF);
		}

		if (selected >= 0) {
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.translatable("message.infinity_gems.selected", GauntletItem.modeName(selected)),
					width / 2, by + (snap ? 24 : 4), 0xFFE08A);
		} else {
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.translatable("message.infinity_gems.no_gems"), width / 2, by + 4, 0xFFAAAA);
		}
		ctx.drawCenteredTextWithShadow(textRenderer,
				Text.translatable("gui.infinity_gems.hint"), width / 2, by + (snap ? 38 : 18), 0xAAAAAA);

		// Suggerimento sopra l'incastro.
		for (GemType type : GemType.values()) {
			int x0 = left + (int) (SLOTS[type.ordinal()][0] * s);
			int y0 = top + (int) (SLOTS[type.ordinal()][1] * s);
			int size = (int) (SLOT * s);
			if (mouseX >= x0 && mouseX < x0 + size && mouseY >= y0 && mouseY < y0 + size) {
				boolean has = !stack.isEmpty() && GauntletItem.hasStone(stack, type);
				ctx.drawTooltip(textRenderer,
						has ? type.getDisplayName() : Text.translatable("gui.infinity_gems.empty_socket"),
						mouseX, mouseY);
			}
		}

		super.render(ctx, mouseX, mouseY, delta);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		ItemStack stack = gauntlet();
		if (stack.isEmpty()) {
			return super.mouseClicked(mouseX, mouseY, button);
		}
		float s = scale();
		int left = left(s);
		int top = top(s);

		for (GemType type : GemType.values()) {
			int x0 = left + (int) (SLOTS[type.ordinal()][0] * s);
			int y0 = top + (int) (SLOTS[type.ordinal()][1] * s);
			int size = (int) (SLOT * s);
			if (mouseX >= x0 && mouseX < x0 + size && mouseY >= y0 && mouseY < y0 + size) {
				if (GauntletItem.hasStone(stack, type)) {
					choose(stack, type.ordinal());
				}
				return true;
			}
		}

		List<Integer> modes = GauntletItem.modes(stack);
		int by = top + (int) (TEX * s) + 6;
		int bx = width / 2 - 45;
		if (modes.contains(GauntletItem.SNAP) && mouseX >= bx && mouseX < bx + 90 && mouseY >= by && mouseY < by + 18) {
			choose(stack, GauntletItem.SNAP);
			return true;
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	private void choose(ItemStack stack, int mode) {
		GauntletItem.setSelected(stack, mode); // subito sul client
		PacketByteBuf buf = PacketByteBufs.create();
		buf.writeInt(mode);
		ClientPlayNetworking.send(ModNetworking.SELECT, buf); // e sul server
	}
}
