package com.infinitygems;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

public final class ModNetworking {
	/** Il client dice al server quale gemma ha scelto nella schermata. */
	public static final Identifier SELECT = new Identifier(InfinityGemsMod.MOD_ID, "select_mode");

	private ModNetworking() {
	}

	public static void register() {
		ServerPlayNetworking.registerGlobalReceiver(SELECT, (server, player, handler, buf, responseSender) -> {
			int mode = buf.readInt();
			server.execute(() -> {
				ItemStack stack = player.getMainHandStack();
				if (!(stack.getItem() instanceof GauntletItem)) {
					stack = player.getOffHandStack();
				}
				if (stack.getItem() instanceof GauntletItem && GauntletItem.modes(stack).contains(mode)) {
					GauntletItem.setSelected(stack, mode);
				}
			});
		});
	}
}
