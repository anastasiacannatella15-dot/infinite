package com.infinitygems;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.PlacedFeature;

public final class ModWorldgen {
	public static final Feature<ShrineConfig> SHRINE = new GemShrineFeature();

	private ModWorldgen() {
	}

	public static void register() {
		Registry.register(Registries.FEATURE, new Identifier(InfinityGemsMod.MOD_ID, "gem_shrine"), SHRINE);

		for (GemType type : GemType.values()) {
			RegistryKey<PlacedFeature> key = RegistryKey.of(RegistryKeys.PLACED_FEATURE,
					new Identifier(InfinityGemsMod.MOD_ID, "shrine_" + type.key()));
			BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
					GenerationStep.Feature.SURFACE_STRUCTURES, key);
		}
	}
}
