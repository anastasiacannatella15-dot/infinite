package com.infinitygems;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/** Un piccolo santuario di pietra con un forziere che custodisce un contenitore. */
public class GemShrineFeature extends Feature<ShrineConfig> {

	private record Theme(Block floor, Block pillar, Block light) {
	}

	public GemShrineFeature() {
		super(ShrineConfig.CODEC);
	}

	private static Theme themeOf(GemType type) {
		return switch (type) {
			case SPACE -> new Theme(Blocks.END_STONE_BRICKS, Blocks.PURPUR_PILLAR, Blocks.END_ROD);
			case MIND -> new Theme(Blocks.CUT_SANDSTONE, Blocks.CHISELED_SANDSTONE, Blocks.GLOWSTONE);
			case REALITY -> new Theme(Blocks.NETHER_BRICKS, Blocks.RED_NETHER_BRICKS, Blocks.SHROOMLIGHT);
			case POWER -> new Theme(Blocks.DEEPSLATE_BRICKS, Blocks.AMETHYST_BLOCK, Blocks.SOUL_LANTERN);
			case TIME -> new Theme(Blocks.PRISMARINE_BRICKS, Blocks.DARK_PRISMARINE, Blocks.SEA_LANTERN);
			case SOUL -> new Theme(Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.CHISELED_POLISHED_BLACKSTONE, Blocks.SOUL_CAMPFIRE);
		};
	}

	@Override
	public boolean generate(FeatureContext<ShrineConfig> context) {
		StructureWorldAccess world = context.getWorld();
		BlockPos origin = context.getOrigin();
		Random random = context.getRandom();
		GemType type = GemType.byKey(context.getConfig().gem());
		if (type == null) {
			return false;
		}

		BlockPos below = origin.down();
		BlockState ground = world.getBlockState(below);
		if (!world.getFluidState(below).isEmpty() || !world.getFluidState(origin).isEmpty()
				|| ground.isIn(BlockTags.LEAVES) || !ground.isSolidBlock(world, below)) {
			return false;
		}

		Theme theme = themeOf(type);
		BlockState floor = theme.floor().getDefaultState();
		BlockState pillar = theme.pillar().getDefaultState();
		BlockState air = Blocks.AIR.getDefaultState();

		// Libera lo spazio e costruisce le fondamenta.
		for (int dx = -3; dx <= 3; dx++) {
			for (int dz = -3; dz <= 3; dz++) {
				for (int dy = 1; dy <= 7; dy++) {
					world.setBlockState(origin.add(dx, dy, dz), air, Block.NOTIFY_ALL);
				}
				for (int dy = -1; dy >= -5; dy--) {
					BlockPos p = origin.add(dx, dy, dz);
					if (!world.getBlockState(p).isSolidBlock(world, p)) {
						world.setBlockState(p, floor, Block.NOTIFY_ALL);
					}
				}
				world.setBlockState(origin.add(dx, 0, dz), floor, Block.NOTIFY_ALL);
			}
		}

		// Quattro pilastri con luce in cima, collegati da un architrave.
		for (int sx = -3; sx <= 3; sx += 6) {
			for (int sz = -3; sz <= 3; sz += 6) {
				for (int dy = 1; dy <= 4; dy++) {
					world.setBlockState(origin.add(sx, dy, sz), pillar, Block.NOTIFY_ALL);
				}
				world.setBlockState(origin.add(sx, 5, sz), theme.light().getDefaultState(), Block.NOTIFY_ALL);
			}
		}
		for (int d = -2; d <= 2; d++) {
			world.setBlockState(origin.add(d, 4, -3), floor, Block.NOTIFY_ALL);
			world.setBlockState(origin.add(d, 4, 3), floor, Block.NOTIFY_ALL);
			world.setBlockState(origin.add(-3, 4, d), floor, Block.NOTIFY_ALL);
			world.setBlockState(origin.add(3, 4, d), floor, Block.NOTIFY_ALL);
		}

		// Piedistallo e forziere con il contenitore.
		world.setBlockState(origin.add(0, 1, 0), pillar, Block.NOTIFY_ALL);
		BlockPos chestPos = origin.add(0, 2, 0);
		world.setBlockState(chestPos, Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, Direction.SOUTH), Block.NOTIFY_ALL);
		LootableContainerBlockEntity.setLootTable(world, random, chestPos,
				new Identifier(InfinityGemsMod.MOD_ID, "chests/shrine_" + type.key()));
		return true;
	}
}
