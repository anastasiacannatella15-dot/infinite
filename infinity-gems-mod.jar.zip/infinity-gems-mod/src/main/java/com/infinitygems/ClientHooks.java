package com.infinitygems;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

/** Ponte verso il codice che esiste solo sul client. */
@Environment(EnvType.CLIENT)
public final class ClientHooks {
	private ClientHooks() {
	}

	public static void openGauntletScreen() {
		MinecraftClient.getInstance().setScreen(new GauntletScreen());
	}
}
