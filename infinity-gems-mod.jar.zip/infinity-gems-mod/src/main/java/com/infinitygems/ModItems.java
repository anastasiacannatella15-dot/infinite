package com.infinitygems;

import java.util.EnumMap;
import java.util.Map;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public final class ModItems {
	public static final Map<GemType, GemItem> GEMS = new EnumMap<>(GemType.class);
	public static final Map<GemType, ContainerItem> CONTAINERS = new EnumMap<>(GemType.class);
	public static Item EMPTY_CASE;
	public static GauntletItem GAUNTLET;
	public static ItemGroup GROUP;

	private ModItems() {
	}

	private static Identifier id(String path) {
		return new Identifier(InfinityGemsMod.MOD_ID, path);
	}

	public static void register() {
		for (GemType type : GemType.values()) {
			GemItem gem = Registry.register(Registries.ITEM, id(type.getStoneId()),
					new GemItem(type, new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof()));
			GEMS.put(type, gem);
		}

		for (GemType type : GemType.values()) {
			ContainerItem container = Registry.register(Registries.ITEM, id(type.getContainerId()),
					new ContainerItem(type, new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof()));
			CONTAINERS.put(type, container);
		}

		EMPTY_CASE = Registry.register(Registries.ITEM, id("empty_case"),
				new Item(new Item.Settings().maxCount(16)));

		GAUNTLET = Registry.register(Registries.ITEM, id("gauntlet"),
				new GauntletItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof()));

		GROUP = Registry.register(Registries.ITEM_GROUP, id("infinity_gems"),
				FabricItemGroup.builder()
						.icon(() -> new ItemStack(GAUNTLET))
						.displayName(Text.translatable("itemGroup.infinity_gems"))
						.entries((context, entries) -> {
							for (GemItem gem : GEMS.values()) {
								entries.add(gem);
							}
							for (ContainerItem container : CONTAINERS.values()) {
								entries.add(container);
							}
							entries.add(EMPTY_CASE);
							entries.add(GAUNTLET);
						})
						.build());
	}
}
