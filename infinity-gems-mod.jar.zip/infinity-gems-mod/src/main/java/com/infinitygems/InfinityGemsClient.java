package com.infinitygems;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.item.ModelPredicateProviderRegistry;
import net.minecraft.util.Identifier;

/** Lato client: fa cambiare l'aspetto del guanto in base alle gemme incastrate. */
@Environment(EnvType.CLIENT)
public class InfinityGemsClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ModelPredicateProviderRegistry.register(
				ModItems.GAUNTLET,
				new Identifier(InfinityGemsMod.MOD_ID, "sockets"),
				(stack, world, entity, seed) -> (float) GauntletItem.getSockets(stack));
	}
}
