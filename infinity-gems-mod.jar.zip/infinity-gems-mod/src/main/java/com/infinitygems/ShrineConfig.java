package com.infinitygems;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.world.gen.feature.FeatureConfig;

/** Quale gemma custodisce il santuario (space, mind, reality, power, time, soul). */
public record ShrineConfig(String gem) implements FeatureConfig {
	public static final Codec<ShrineConfig> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.STRING.fieldOf("gem").forGetter(ShrineConfig::gem)
	).apply(instance, ShrineConfig::new));
}
