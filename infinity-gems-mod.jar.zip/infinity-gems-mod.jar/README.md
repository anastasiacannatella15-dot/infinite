# Infinity Gems (Fabric, Minecraft 1.20.1)

Sei gemme dell'infinito, sei contenitori, un guanto con incastri e la modalità Schiocco.
Codice e texture sono originali.

## Come compilare

Servono **Java 17 o più recente** e **Gradle 8.5+** (oppure IntelliJ IDEA, che scarica tutto da solo).

```
gradle build
```

Il file pronto da mettere nella cartella `mods` esce in `build/libs/infinity-gems-1.0.0.jar`.
Per giocare servono anche Fabric Loader (0.15+) e **Fabric API** per 1.20.1.

> La cartella non include `gradlew` perché è stata creata senza accesso a internet.
> Con Gradle installato basta `gradle wrapper --gradle-version 8.5` una volta sola.

## Le gemme

| Gemma | Clic destro |
|---|---|
| Spazio | Teletrasporto dove guardi (24 blocchi) |
| Mente | Mostri vicini: luce, lentezza, debolezza. Tu: visione notturna |
| Realtà | Mostri vicini diventano galline |
| Potere | Fulmine dove guardi + danno ai mostri |
| Tempo | Velocità e fretta per te, mostri rallentati, colture accelerate |
| Anima | Cura completa, assorbimento, toglie gli effetti cattivi |

## Contenitori e guanto

- **Contenitori** (Cubo, Scettro, Fiala, Sfera, Amuleto, Calice): clic destro usa la gemma, Maiusc + clic destro la estrae e ti lascia una **Custodia Vuota**.
- **Guanto**: tieni una gemma o un contenitore nell'altra mano e clic destro per incastrarla. Clic destro usa la gemma scelta, Maiusc + clic destro cambia gemma. Con una Custodia Vuota nell'altra mano, Maiusc + clic destro estrae la gemma scelta.
- **Schiocco**: con tutte e 6 le gemme nel guanto compare la modalità Schiocco. Fa svanire metà dei mostri nel raggio di 96 blocchi (mai giocatori, animali, villager o Wither). Ricarica 60 secondi, ti lascia debole e lento.

## Dove si trovano

- Craft: gemme (4 ingredienti + blocco di diamante), Custodia Vuota, contenitori (gemma + Custodia Vuota), Guanto (oro + netherite).
- Forzieri: Guanto nell'armaiolo del villaggio; Cubo (fortezza), Scettro (città dell'End), Fiala (fortezza del Nether), Sfera (rovine sommerse grandi), Amuleto (biblioteca della fortezza), Calice (bastione).
