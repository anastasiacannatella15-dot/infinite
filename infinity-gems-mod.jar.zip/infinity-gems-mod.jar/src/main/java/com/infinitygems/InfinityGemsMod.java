package com.infinitygems;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InfinityGemsMod implements ModInitializer {
	public static final String MOD_ID = "infinity_gems";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModItems.register();
		ModLoot.register();
		LOGGER.info("Infinity Gems caricata: 6 gemme, 6 contenitori e il guanto sono pronti.");
	}
}
